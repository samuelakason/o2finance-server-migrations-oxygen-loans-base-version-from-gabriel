// import 'package:flutter/material.dart';
// import 'package:get/get_state_manager/src/simple/get_state.dart';
// import 'package:oxygen_loans/controllers/loan/loan.dart';

// class ActiveLoans extends StatelessWidget {
//   const ActiveLoans({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return GetBuilder<LoanUserController>(
//         initState: (controller) {},
//         builder: (controller) {
//         return Container(child: ,);
//       }
//     );
//   }
// }
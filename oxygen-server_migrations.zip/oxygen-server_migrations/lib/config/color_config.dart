import 'package:flutter/material.dart';

const oxygenPrimaryColor = Color(0xFF1AB6DC);
const oxygenSecColor = Color(0xFFfffff);

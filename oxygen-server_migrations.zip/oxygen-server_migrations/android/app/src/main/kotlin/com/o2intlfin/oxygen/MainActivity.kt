package com.o2intlfin.oxygen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

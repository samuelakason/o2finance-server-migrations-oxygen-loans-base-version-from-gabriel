package com.example.xygen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
